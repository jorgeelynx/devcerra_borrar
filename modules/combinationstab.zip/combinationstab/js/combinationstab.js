/**
 * PrestaShop module created by VEKIA, a guy from official PrestaShop community ;-)
 *
 * @author    VEKIA https://www.prestashop.com/forums/user/132608-vekia/
 * @copyright 2010-9999 VEKIA
 * @license   This program is not free software and you can't resell and redistribute it
 *
 * CONTACT WITH DEVELOPER http://mypresta.eu
 * support@mypresta.eu
 */

$(document).ready(function () {
    $("#add_to_cart_bulk").click(function () {
        var arr = [];
        if (ctp_cartexists == 0)
        {
            $("#ct_matrix input.qty").each(function () {
                if ($(this).val() > 0) {
                    arr.push($('#' + $(this).attr("alt") + '_idCombination').val());
                }
            });
            if (typeof arr !== 'undefined' && arr.length > 0) {
                $.ajax({
                    type: "POST",
                    url: prestashop.urls.base_url + "modules/combinationstab/ajax_combinationstab.php?setCartBeforeAdd=1",
                    success: function () {
                        $("#ct_matrix input.qty").each(function () {
                            ctp_cartexist = 1;
                            if ($(this).val() > 0)
                            {
                                ajaxCart.add($('#product_page_product_id').val(), $('#' + $(this).attr("alt") + '_idCombination').val(), true, '#add_to_cart_bulk', $('#' + $(this).attr("alt") + '_idQty').val(), null);
                            }
                        });
                    },
                    error: function () {
                        $("#ct_matrix input.qty").each(function () {
                            if ($(this).val() > 0)
                            {
                                ajaxCart.add($('#product_page_product_id').val(), $('#' + $(this).attr("alt") + '_idCombination').val(), true, '#add_to_cart_bulk', $('#' + $(this).attr("alt") + '_idQty').val(), null);
                            }
                        });
                    }
                });
            }
        }
        else if (ctp_cartexists == 1)
        {
            $("#ct_matrix input.qty").each(function () {
                if ($(this).val() > 0) {
                    ajaxCart.add($('#product_page_product_id').val(), $('#' + $(this).attr("alt") + '_idCombination').val(), true, '#add_to_cart_bulk', $('#' + $(this).attr("alt") + '_idQty').val(), null);
                }
            });
        }

        $('.modal-dialog .close').click(function(){
            $('#blockcart-modal, .modal-backdrop').hide();
        });
    });

    $(".qty").change(function () {
        if ($(this).val() > 0) {
            $(this).parent().parent().attr('class', 'ct_matrix_row ctp_checked');
            updateCombinationsTotal($(this).val());
        } else {
            $(this).parent().parent().attr('class', 'ct_matrix_row');
            updateCombinationsTotal($(this).val());
        }
    });

    function updateCombinationsTotal(val) {
        $('.combinations_tab_price').html("<img src='"+ prestashop.urls.base_url + "modules/combinationstab/img/loading.gif'/>");
        if (ctp_psum == 1) {
            var products = [];
            $('#ct_matrix tr.ctp_checked').find("input[name='id_product_attribute']").each(function () {
                products.push({id_product_attribute: $(this).val(), id_product: $(".ctab_id_product").val(), quantity: $("#ct_matrix_" + $(this).val() + "_idQty").val()});
            });

            $.post(prestashop.urls.base_url + "modules/combinationstab/ajax_combinationstab.php", {
                getPrice: JSON.stringify(products)
            }, function (data) {
                $('.combinations_tab_price').html(data);
            });
        }
    }

    prestashop.on('updateCart', function (event) {
        var $body = $('body');
        $('.modal-backdrop').remove();
        $body.removeClass('modal-open');
        $body.one('click', '#blockcart-modal', function (event) {
            $('#blockcart-modal').remove();
            $('.modal-backdrop').remove();
            $body.removeClass('modal-open');
        });
        $body.one('click', '.modal-backdrop', function (event) {
            $('.modal-backdrop').remove();
            $('#blockcart-modal').remove();
            $body.removeClass('modal-open');
        });
    });

});