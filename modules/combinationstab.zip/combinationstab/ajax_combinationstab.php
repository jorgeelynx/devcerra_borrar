<?php
/**
 * PrestaShop module created by VEKIA, a guy from official PrestaShop community ;-)
 *
 * @author    VEKIA https://www.prestashop.com/forums/user/132608-vekia/
 * @copyright 2010-2017 VEKIA
 * @license   This program is not free software and you can't resell and redistribute it
 *
 * CONTACT WITH DEVELOPER http://mypresta.eu
 * support@mypresta.eu
 */
include_once('../../config/config.inc.php');
include_once('../../init.php');
include_once('combinationstab.php');
$thismodule = new combinationstab();

if (Tools::getValue('setCartBeforeAdd', 'false') != 'false')
{
    $context = Context::getContext();
    if (!$context->cart->id)
    {
        if (Context::getContext()->cookie->id_guest)
        {
            $guest = new Guest(Context::getContext()->cookie->id_guest);
            $context->cart->mobile_theme = $guest->mobile_theme;
        }
        $context->cart = new Cart();
        $context->cart->id_customer = (int)($context->cookie->id_customer);
        $context->cart->id_address_delivery = (int)(Address::getFirstCustomerAddressId($context->cart->id_customer));
        $context->cart->id_address_invoice = $context->cart->id_address_delivery;
        $context->cart->id_lang = (int)($context->cookie->id_lang);
        $context->cart->id_currency = (int)($context->cookie->id_currency);
        $context->cart->id_carrier = 1;
        $context->cart->recyclable = 0;
        $context->cart->add();
        $context->cart->update();
        $context->cookie->__set('id_cart', $context->cart->id);
    }
}

if (Tools::getValue('search', 'false') != 'false')
{
    $result = $thismodule->searchproduct(Tools::getValue('search'));
    if (count($result) > 0)
    {
        foreach ($result as $value)
        {
            echo '<p style="display:block; clear:both; padding:0px; padding-top:3px; margin:0px;">' . $value['name'] . '<span style="display:inline-block; background:#FFF; cursor:pointer; border:1px solid black; padding:1px 3px;margin-left:5px;" onclick="$(\'.ctp_pr_ids\').val($(\'.ctp_pr_ids\').val()+\'' . $value['id_product'] . ',\')">' . $thismodule->addproduct . '</span></p>';
        }
    }
    else
    {
        echo $thismodule->noproductsfound;
    }
}

if (Tools::getValue('getPrice', 'false') != 'false')
{
    $elements = json_decode(Tools::getValue('getPrice'));
    $vv = 0;
    $qty = 0;
    $products = array();
    foreach ($elements AS $key => $value)
    {
        foreach ($value AS $k => $v)
        {
            if (trim((string)$k) == 'id_product_attribute')
            {
                $id_product_attribute = (int)$v;
            }
            elseif (trim((string)$k) == 'id_product')
            {
                $id_product = (int)$v;
            }
            elseif (trim((string)$k) == 'quantity')
            {
                $quantity = (int)$v;
            }
        }
        $qty = $qty + $quantity;
        $product = new Product($id_product, true);
        $vv = $vv + ($quantity * $product->getPrice((Configuration::get('ctp_prices_tax') == 1 ? false : true), $id_product_attribute, 6, null, false, true, $quantity));

        $products[] = array(
            'id_product' => $id_product,
            'id_product_attribute' => $id_product_attribute,
            'id_shop' => context::getContext()->shop->id,
            'cart_quantity' => $quantity
        );

    }

    if (isset($product))
    {
        if (Validate::isLoadedObject($product))
        {
            $all_qty_price = $product->getPrice((Configuration::get('ctp_prices_tax') == 1 ? false : true), null, 6, null, false, true, $qty);
            if (($all_qty_price * $qty) != $vv)
            {
                $all_price = 0;
                foreach ($products AS $key => $tproduct)
                {
                    //calculation of total value of selected combinations with included global quantity discount
                    $all = $product->getPrice(true, $tproduct['id_product_attribute'], 6, null, false, true, $qty);
                    $all_price = $all_price + $all * $tproduct['cart_quantity'];
                }
                echo Tools::displayPrice($all_price);
            }
            else
            {
                echo Tools::displayPrice($vv);
            }
        }
        else
        {
            echo Tools::displayPrice(0);
        }
    }
    else
    {
        echo Tools::displayPrice(0);
    }
}